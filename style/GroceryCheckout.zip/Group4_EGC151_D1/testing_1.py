menu = [
    {"Category": "Drinks", "Code": "CD10", "Items": [
        {"name": "Neo's Green Tea", "code": "N32", "price": 3.00},
        {"name": "Melo Chocolate Malt Drink", "code": "M13", "price": 2.85},
        {"name": "Very-Fair Full Cream Milk", "code": "V76", "price": 3.50},
        {"name": "Nirigold UHT Milk", "code": "N14", "price": 4.15}
    ]},
    {"Category": "Beer", "Code": "CB20", "Items": [
        {"name": "Lion (24 x 320 ml)", "code": "L11", "price": 52.0},
        {"name": "Panda (24 x 320 ml)", "code": "P21", "price": 78.0},
        {"name": "Axe (24 x 320 ml)", "code": "A54", "price": 58.0},
        {"name": "Henekan (24 x 320 ml)", "code": "H91", "price": 68.0}
    ]},
    {"Category": "Frozen", "Code": "CF30", "Items": [
        {"name": "Edker Ristorante Pizza 355g", "code": "E11", "price": 6.95},
        {"name": "Fazzler Frozen Soup 500g", "code": "F43", "price": 5.15},
        {"name": "CP Frozen Ready Meal 250g", "code": "CP31", "price": 4.12},
        {"name": "Duitoni Cheese 270g", "code": "D72", "price": 5.60}
    ]},
    {"Category": "Household", "Code": "CH40", "Items": [
        {"name": "FP Facial Tissues", "code": "FP76", "price": 9.50},
        {"name": "FP Premium Kitchen Towel", "code": "FP32", "price": 5.85},
        {"name": "Klinex Toilet Tissue Rolls", "code": "K22", "price": 7.50},
        {"name": "Danny Softener", "code": "D14", "price": 9.85},
    ]},
    {"Category": "Snacks", "Code": "CS50", "Items": [
        {"name": "Singshort Seaweed", "code": "SS93", "price": 3.10},
        {"name": "Mei Crab Cracker", "code": "MC14", "price": 2.05},
        {"name": "Reo Pokemon Cookie", "code": "R35", "price": 4.80},
        {"name": "Huat Seng Crackers", "code": "HS11", "price": 3.55}
    ]}
]

cart = []

def displayMenu():
    header = f"{'S/N':^3} {'Category':^30} {'Item':^30} {'Code':^12} {'Price':^8}"
    print(header)
    print("-" * len(header))
    for category in menu:
        items = category["Items"]
        category_title = f"{category['Category']} ({category['Code']})"
        for i, item in enumerate(items, start=1):
            print(
                f"{i:<3} {category_title if i == 1 else '':^30} {item['name']:<30} {item['code']:^12} ${item['price']:<8.2f}"
            )
        print()

def addToCartFromCategory(category):
    while True:
        displayCategory(category)
        item_choice = int(input("Enter the item number to add to cart (or '0' to go back): ")) - 1
        if item_choice == -1:
            return
        if 0 <= item_choice < len(category["Items"]):
            item = category["Items"][item_choice]
            quantity = int(input(f"Enter quantity for {item['name']}: "))
            if quantity <= 0:
                print("Quantity must be a positive number. Please try again.")
                continue
            cart.append({"name": item["name"], "code": item["code"], "price": item["price"], "quantity": quantity})
            print(f"Added {quantity} x {item['name']} to cart.")
        else:
            print("Invalid item choice. Please try again.")

def displayCategory(category):
    header = f"{'S/N':^3} {'Category':^30} {'Item':^30} {'Code':^12} {'Price':^8}"
    print(header)
    print("-" * len(header))
    category_title = f"{category['Category']} ({category['Code']})"
    for i, item in enumerate(category["Items"], start=1):
        print(
            f"{i:<3} {category_title if i == 1 else '':^30} {item['name']:<30} {item['code']:^12} ${item['price']:<8.2f}"
        )

def printCart():
    print("\nYour cart:")
    if not cart:
        print("Your cart is empty.")
    else:
        for i, item in enumerate(cart, start=1):
            print(f"{i}. {item['quantity']} x {item['name']} (Code: {item['code']}) - ${item['price'] * item['quantity']:.2f}")

def editQuantity():
    printCart()
    if not cart:
        return
    while True:
        item_choice = int(input("Enter the item number to edit quantity (or '0' to finish): ")) - 1
        if item_choice == -1:
            break
        if 0 <= item_choice < len(cart):
            new_quantity = int(input(f"Enter new quantity for {cart[item_choice]['name']}: "))
            if new_quantity <= 0:
                print("Quantity must be a positive number. Please try again.")
                continue
            cart[item_choice]['quantity'] = new_quantity
            print(f"Updated quantity for {cart[item_choice]['name']} to {new_quantity}.")
        else:
            print("Invalid item choice. Please try again.")

def removeFromCart():
    printCart()
    if not cart:
        return
    while True:
        item_choice = int(input("Enter the item number to remove (or '0' to finish): ")) - 1
        if item_choice == -1:
            break
        if 0 <= item_choice < len(cart):
            removed_item = cart.pop(item_choice)
            print(f"Removed {removed_item['name']} from the cart.")
        else:
            print("Invalid item choice. Please try again.")

def calculateTotal():
    total = sum(item['price'] * item['quantity'] for item in cart)
    return total

def billing():
    total_amount = calculateTotal()
    if total_amount == 0:
        print("Your cart is empty. No billing needed.")
        return
    print("Are you eligible for any discount privileges?")
    print("1: Seniors (10%)")
    print("2: Members (8%)")
    print("3: NS Men (5%)")
    print("4: No Discount")
    discount_choice = int(input("Enter your choice: "))
    discount = 0
    if discount_choice == 1:
        discount = total_amount * 0.10
    elif discount_choice == 2:
        discount = total_amount * 0.08
    elif discount_choice == 3:
        discount = total_amount * 0.05
    elif discount_choice == 4:
        discount = 0
    else:
        print("Invalid choice. No discount applied.")
    discounted_total = total_amount - discount
    gst_amount = discounted_total * 0.09
    final_amount = discounted_total + gst_amount
    print("\nBill Summary:")
    print(f"{'S/N':<5} {'Item':<30} {'Quantity':<10} {'Price':<10}")
    print("-" * 60)
    for i, item in enumerate(cart, start=1):
        print(f"{i:<5} {item['name']:<30} {item['quantity']:<10} ${item['price'] * item['quantity']:<10.2f}")
    print("-" * 60)
    print(f"{'Total price before:':<45} ${total_amount:.2f}")
    if discount > 0:
        print(f"{'Discount:':<45} -${discount:.2f}")
    print(f"{'GST (9%):':<45} +${gst_amount:.2f}")
    print(f"{'Final payable amount:':<45} ${final_amount:.2f}")
    exit()

def main():
    displayMenu()
    while True:
        print("Choose an option:")
        print("1: Drinks")
        print("2: Beer")
        print("3: Frozen")
        print("4: Household")
        print("5: Snacks")
        print("6: View Cart")
        print("7: Edit Quantities")
        print("8: Remove Items")
        print("9: Billing")
        choice = int(input("Enter your choice: ")) - 1
        if 0 <= choice < len(menu):
            chosen_category = menu[choice]
            addToCartFromCategory(chosen_category)
        elif choice == 5:
            printCart()
        elif choice == 6:
            editQuantity()
        elif choice == 7:
            removeFromCart()
        elif choice == 8:
            billing()
        else:
            print("Invalid choice. Please try again.")

main()